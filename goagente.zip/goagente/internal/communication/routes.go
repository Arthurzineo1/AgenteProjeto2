package communication

// Definindo as rotas como strings
const (
	EnviaCoreInfos     = "v3/1804faad-24f0-4e25-ada2-945dfb483fb2"
	EnviaSystemInfos   = "v3/1804faad-24f0-4e25-ada2-945dfb483fb2"
	EnviaProgramInfos  = "v3/1804faad-24f0-4e25-ada2-945dfb483fb2"
	EnviaHardwareInfos = "v3/1804faad-24f0-4e25-ada2-945dfb483fb2"
)
