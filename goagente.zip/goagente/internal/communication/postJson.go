package communication

import (
	"fmt"
	"goagente/internal/logging"
)

func SendHardwareInfo(client *APIClient, route string, jsonData string) {
	resp, err := client.GenericPost(route, jsonData)
	if err != nil {
		logging.Error(err)
		fmt.Println("Erro ao enviar as informações de hardware para o servidor:", err)
		return
	}
	if resp.StatusCode != 200 {
		fmt.Println("Resultado JSON:", jsonData)
		fmt.Println("Erro ao enviar as informações de hardware para o servidor.")
		newErr := fmt.Errorf("erro ao enviar as informações de hardware para o servidor, status: %s", resp.Status)
		logging.Error(newErr)
	} else {
		fmt.Println("Resposta do servidor:", resp.Status)
		fmt.Println("Resultado JSON:", jsonData)
		fmt.Println("Informações de hardware enviadas com sucesso.")
		fmt.Println("")
		logging.Info("Informações de hardware enviadas com sucesso.")
	}
}
